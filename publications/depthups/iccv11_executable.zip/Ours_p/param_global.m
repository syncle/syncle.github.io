% always able to select
param.display_result = true;
param.write_result = true;
param.write_vrml = false;
param.verbose = true;

% default parameters
param.window_size = 3;              % default 3
param.var_scale = 1;                % default 1
param.suppress_ratio_segment = 1; % default 0.3
param.suppress_ratio_depth = 0.7;   % default 0.7
param.suppress_ratio_edge = 1;    % default 0.3

param.NLMwsize = 5;
param.NLMvar_scale = 10e5;

% constraint weighting for depth initial
param.lambda = 5;
%param.lambda = 1/10; % for noisy input
%param.lambda = 1/100;

% weightning term
param.apply_weight_from_edge = true;
param.apply_weight_from_segment = true;
param.apply_weight_from_depth = false;
param.parallel_lmatrix = false;