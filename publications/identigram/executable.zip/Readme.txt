====================================================
An executable code package of
Identigram/Watermark Removal Using Cross-channel Correlation, CVPR 2012
author : Jaesik Park (jspark@rcv.kaist.ac.kr)
2012.03.12
====================================================

This package contains MILCA for searching transformed image domain.
For more details on MILCA, please visit (http://www.klab.caltech.edu/~kraskov/MILCA/)

How to use : Please see manual.pdf
OS : I tested this package with Matlab 2011b in Win7 32bit/64bit. 
