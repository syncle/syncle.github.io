% hologram texture reduction using nearest smooth constraints
% please see input images to check the roll of each one

% auther : jspark
% last modified : 2011. 07. 28


%% initialize
clear all;
%close all;
clc;

filepath = 'img\identigram\';
filename = '1.bmp';

%% reads images and param
param = getparam(filepath, filename);
img = double(imread([filepath, filename]))/255;
cimg = img;
    
%% main algorithm
status = true;

while(status)
        
    % interactive ICA
    [subimg xy] = fn_interactivecrop(cimg);             
    [trimg W] = fn_ICA(subimg);    
    
    h = size(subimg,1); w = size(subimg,2);    %

    % make affinity equation
    Affmat = fn_smooth(trimg, param);
        
    % problem solving
    [Imat b] = fn_make_b(trimg, param);
    x = fn_solve_linear(Affmat, Imat, b);

    % get result
    trimg = fn_get_result(trimg,x,h,w);
    rstimg = fn_InvTr(trimg, W);
    
    fn_viewba(img, cimg, rstimg, xy);
    
    cimg = fn_askapply(cimg,rstimg,xy);
    status = fn_asktryagain();

end

%% save final result
fn_save_result(filepath, filename, cimg, param);