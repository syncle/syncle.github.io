
param.filepath = 'data\';
param.rstpath = param.filepath;

param.color_t = '*-color.png';
param.depth_t = '*-depth.png';
param.depth_t = '*-depth.png';
param.rst_t = '%s-rst-ours.png';
param.seg_t = '%s-seg.txt';